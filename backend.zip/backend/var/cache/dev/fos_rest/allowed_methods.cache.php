<?php return array (
  'group_apiapp_group_readallgroups' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'group_apiapp_group_addgroup' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'group_apiapp_group_readgroup' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'group_apiapp_group_updategroup' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'group_apiapp_group_deletegroup' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'group_apiapp_group_groupadduser' => 
  array (
    0 => 'PATCH',
  ),
  'group_apiapp_group_groupremoveuser' => 
  array (
    0 => 'PATCH',
  ),
  'user_apiapp_user_readallusers' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'user_apiapp_user_adduser' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'user_apiapp_user_readuser' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'user_apiapp_user_updateuser' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'user_apiapp_user_deleteuser' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'user_apiapp_user_getusergroups' => 
  array (
    0 => 'GET',
  ),
);